<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAprendizParticipesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('aprendiz_participes', function (Blueprint $table) {
            $table->increments("naprndiz");
            $table->string("sesiones_realizadas");
            $table->boolean("finalizado");
            $table->bigInteger("documento_aprendizs");
            $table->bigInteger("documento_usuarios");
            $table->foreign("documento_aprendizs")->references("documento")->on("aprendizs");
            $table->foreign("documento_usuarios")->references("documento")->on("usuarios");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('aprendiz_participes');
    }
}
