<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDatoEventosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dato_eventos', function (Blueprint $table) {
            $table->increments("nevento");
            $table->datetime("fechayhora");
            $table->string("duracion");
            $table->string("lugar");
            $table->integer("sesiones");
            $table->string("codigoevento_evento",9);
            $table->bigInteger("documento_aprendizs");
            $table->foreign("documento_aprendizs")->references("documento")->on("aprendizs");
            $table->foreign("codigoevento_evento")->references("codigoevento")->on("eventos");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dato_eventos');
    }
}
