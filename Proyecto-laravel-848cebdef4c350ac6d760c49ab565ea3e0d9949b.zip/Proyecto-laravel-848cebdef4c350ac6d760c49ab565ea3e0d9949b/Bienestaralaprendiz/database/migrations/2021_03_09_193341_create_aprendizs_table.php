<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAprendizsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('aprendizs', function (Blueprint $table) {
            $table->string("tipodocumento",250);
            $table->bigInteger("documento")->primary();
            $table->string("nombre",250);
            $table->string("apellido",250);
            $table->string("genero",250);
            $table->date("fechanacimiento",250);
            $table->string("edad",3);
            $table->string("programa",250);
            $table->string("idficha",250);
            $table->string("correo",250);
            $table->string("telefono",250);
            $table->string("ciudad",250);
            $table->string("barrio",250);
            $table->string("direccion",250);
            $table->string("eps",250);
            $table->string("tipodocumentoA",250);
            $table->bigInteger("documentoA");
            $table->string("nombrecompleto",250);
            $table->string("sexo",250);
            $table->date("fechanacimientoA",250);
            $table->string("correoA",250);
            $table->string("telefonoA",250);
            $table->string("direccionA",250);
            $table->string("contraseña",250);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('aprendizs');
    }
}
