<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAprendizConvocatoriasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('aprendiz_convocatorias', function (Blueprint $table) {
            
                $table->increments("idconvocatoria");
                $table->boolean("finalizado");
                $table->string("seleccionado");
                $table->datetime("fechayhora");
                $table->bigInteger("documento_aprendizs");
                $table->string("codigo_convocatoria");
                $table->foreign("documento_aprendizs")->references("documento")->on("aprendizs");
                $table->foreign("codigo_convocatoria")->references("codigoconvocatoria")->on("convocatorias");
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('aprendiz_convocatorias');
    }
}
