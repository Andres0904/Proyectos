<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCitasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('citas', function (Blueprint $table) {
            $table->increments("ncita");
            $table->string("tipocita",80);
            $table->datetime("fechayhora");
            $table->string("referido",80)->nullable();
            $table->bigInteger("documento");
            $table->string("asistio");
            $table->boolean("finalizado");
            $table->bigInteger("documento_aprendizs");
            $table->foreign("documento_aprendizs")->references("documento")->on("aprendizs");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('citas');
    }
}
