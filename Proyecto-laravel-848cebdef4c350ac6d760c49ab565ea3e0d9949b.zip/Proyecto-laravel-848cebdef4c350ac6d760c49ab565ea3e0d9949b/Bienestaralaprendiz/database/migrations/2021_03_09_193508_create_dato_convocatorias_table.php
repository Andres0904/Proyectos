<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDatoConvocatoriasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dato_convocatorias', function (Blueprint $table) {
            $table->increments("nconvocatoria");
            $table->bigInteger("Documento");
            $table->string("tipodocumento",250);
            $table->string("personaencargada",250);
            $table->date("fecha",250);
            $table->string("codigoconvocatoria_convocatorias")->nullable();
            $table->foreign("codigoconvocatoria_convocatorias")->references("codigoconvocatoria")->on("convocatorias");
        });
       
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dato_convocatorias');
    }
}
