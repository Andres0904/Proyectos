<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dato_evento extends Model
{
    //
}
