<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class aprendiz_participe extends Model
{
    //
}
