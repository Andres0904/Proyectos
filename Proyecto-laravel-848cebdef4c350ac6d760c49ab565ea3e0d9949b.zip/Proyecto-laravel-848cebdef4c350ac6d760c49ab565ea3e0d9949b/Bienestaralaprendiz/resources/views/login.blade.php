<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title></title>

    <style type="text/css">
        /*#form1 {
            height: 1197px;
            width: 937px;
        }*/
       .login-page {
    width: 360px;
    padding: 8% 0 0;
    margin: auto;
  }
  
  .form {
    position: relative;
    z-index: 1;
    background: #FFFFFF;
    max-width: 360px;
    margin: 0 auto 100px;
    padding: 45px;
    text-align: center;
    box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
  }
  .form input {
    font-family: "Roboto", sans-serif;
    outline: 0;
    background: #f2f2f2;
    width: 100%;
    border: 0;
    margin: 0 0 15px;
    padding: 15px;
    box-sizing: border-box;
    font-size: 14px;
  }
  .form button {
    font-family: "Roboto", sans-serif;
    text-transform: uppercase;
    outline: 0;
    background: #4CAF50;
    width: 100%;
    border: 0;
    padding: 15px;
    color: #FFFFFF;
    font-size: 14px;
    -webkit-transition: all 0.3 ease;
    transition: all 0.3 ease;
    cursor: pointer;
  }
  .form button:hover,.form button:active,.form button:focus {
    background: #43A047;
  }
  .form .message {
    margin: 15px 0 0;
    color: #b3b3b3;
    font-size: 12px;
  }
  .form .message a {
    color: #4CAF50;
    text-decoration: none;
  }
  .form .register-form {
    display: none;
  }
  .container {
    position: relative;
    z-index: 1;
    max-width: 300px;
    margin: 0 auto;
  }
  .container:before, .container:after {
    content: "";
    display: block;
    clear: both;
  }
  .container .info {
    margin: 50px auto;
    text-align: center;
  }
  .container .info h1 {
    margin: 0 0 15px;
    padding: 0;
    font-size: 36px;
    font-weight: 300;
    color: #1a1a1a;
  }
  .container .info span {
    color: #4d4d4d;
    font-size: 12px;
  }
  .container .info span a {
    color: #000000;
    text-decoration: none;
  }
  .container .info span .fa {
    color: #EF3B3A;
  }
  body {
    background: #76b852; /* fallback for old browsers */
    background: -webkit-linear-gradient(right, #76b852, #8DC26F);
    background: -moz-linear-gradient(right, #76b852, #8DC26F);
    background: -o-linear-gradient(right, #76b852, #8DC26F);
    background: linear-gradient(to left, #76b852, #8DC26F);
    font-family: "Roboto", sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;      
  }
    </style>

</head>
<body>
 <!-- <link href="assets/css/StyleSheet2.css" rel="stylesheet" />
    <form id="form1" runat="server">
       <div class="login">
				<h3 class="text-center">Inicio de sesión</h3>
				<div class="form-group">
                    <label for="Rol">Rol</label> <br />
                    <Select name = "Rol" ID="ddlRol" runat="server" Height="46px" Width="273px">

                        <Option value = "Aprendiz"> Aprendiz</option>
                        
                        <Option value = "Instructor"> Instructor</option>
                        
                        <Option value = "Administrativo"> Administrativo </option>

                        <Option value = "Administrativoapoyos">Administrativo Apoyos</option>

                        <Option value = "Administrativoculturaydeporte">Administrativo Cultura y deporte</option>

                        <Option value = "Administrativoenfermeria">Administrativo Enfermeria</option>

                        <Option value = "Administrativopsicologia">Administrativo Psicologia</option>

                        <Option value = "Administrativolider">Administrativo Lider</option>
                        
                    </Select>
                    <br><br>
					<label for="TipodeDocumento">Tipo de Documento</label> <br />
                    <Select name = "Tipo de Documento" ID="ddlTipoDoc" runat="server" Height="46px" Width="273px">

                        <Option value = "TI"> TI</option>
                        
                        <Option value = "Cc"> Cc</option>
                        
                        <Option value = "CE"> CE </option>
                        
                    </Select>
                  
				</div>
		        <div class="form-group">
					<label class="Documento">Documento</label>
					<input type="text"  ID="txtDocumento" class="form-control" runat="server" Height="30px" Width="258px">
				</div>
				<div class="form-group">
					<label for="Pass">Contraseña</label>					
                    <input type="password" ID="txtContraseña" class="form-control" runat="server" TextMode="Password" Width="265px"> 
				</div>

				<p class="text-center">		
                    <input value="Ingresar" type="button" id="btnIngresar" class="btn btn-primary btn-block" runat="server"  >
					<input value="Registrarse" type="button" ID="btnRegistrarse" class="btn btn-primary btn-block" runat="server" />
                    
                    
				</p>
			</div>  
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        </form>
	-->
   
    <!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bienestar Al aprendiz</title>
  <style>
    * {
 box-sizing: border-box;
 }
 
 *:focus {
     outline: none;
 }
 body {
 font-family: Arial;
 background-color: #3498DB;
 padding: 50px;
 }
 .login {
 margin: 20px auto;
 width: 300px;
 }
 #login-screen {
 background-color:  #b2b4b4;
 padding: 10px;
 width: 250px;
 border: 2px solid transparent;
 }
 
 .login-screen {
 background-color: #FFF;
 padding: 20px;
 border-radius: 5px
 
 }
 .app-title {
 text-align: center;
 color: #777;
 }
 
 .login-form {
 text-align: center;
 }
 .control-group {
 margin-bottom: 10px;
 }
 
 input {
 text-align: center;
 background-color: #b2b4b4;
 border: 2px solid transparent;
 border-radius: 3px;
 font-size: 16px;
 font-weight: 200;
 padding: 10px 0;
 width: 250px;
 transition: border .5s;
 }
 
 input:focus {
 border: 2px solid #3498DB;
 box-shadow: none;
 }
 
 .btn {
   border: 2px solid transparent;
   background: #3498DB;
   color: #ffffff;
   font-size: 16px;
   line-height: 25px;
   padding: 10px 0;
   text-decoration: none;
   text-shadow: none;
   border-radius: 3px;
   box-shadow: none;
   transition: 0.25s;
   display: block;
   width: 250px;
   margin: 0 auto;
 }
 
 .btn:hover {
   background-color: #2980B9;
 }
 
 .login-link {
   font-size: 12px;
   color: #444;
   display: block;
     margin-top: 12px;
 }
   </style>
</head>

    <div class="login">
      <div class="login-screen">
        <div class="app-title">
          <h5>Bienestar al aprendiz</h5>
        </div>
  
        <div class="login-form">

          <label for="cars"></label>

          <div class="control-group">
            <select name="cars"class="login-field" value=""  id="login-screen">
              <option value="">Cedula de ciudadania</option>
              <option value="">Tarjeta de identidad</option>
              <option value="">Cedula de extranjeria</option>
              <option value="">Pasaporte</option>
            </select>
          </div>

          <div class="control-group">
          <input type="text" class="login-field" value="" placeholder="N° documento" id="login-name">
          <label class="login-field-icon fui-user" for="login-name"></label>
          </div>
  
          <div class="control-group">
          <input type="password" class="login-field" value="" placeholder="Contraseña" id="login-pass">
          <label class="login-field-icon fui-lock" for="login-pass"></label>
          </div>
  
          <a class="btn btn-primary btn-large btn-block" href="#">Ingresar</a>
          <br>
          <a class="btn btn-primary btn-large btn-block" href="CrearperfilAprendiz.html">Registrarse</a>
          <a class="login-link" href="#">Olvido la contraseña?</a>
        </div>
      </div>
    </div>
 
</html>
</body>
</html>