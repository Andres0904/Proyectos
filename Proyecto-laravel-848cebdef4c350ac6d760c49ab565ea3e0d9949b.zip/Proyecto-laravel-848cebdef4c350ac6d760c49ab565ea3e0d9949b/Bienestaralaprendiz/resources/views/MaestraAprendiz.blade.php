
<!DOCTYPE html>

<html>
<head>
        
		<title>Bienestar Al Aprendiz</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<meta name="keywords" content="sena, adsi, web, asp.net">
		<meta name="description" content=" desarrollo web con asp.net">
		<meta name="author" content="José Fernando Murillo Arango">
        <link href="../assets/css/StyleSheet1.css" rel="stylesheet" />
	    <style type="text/css">
            .auto-style2 {
                margin: auto;
                overflow: hidden;
                height: 102px;
                width: 941px;
            }
            #marca {
                height: 59px;
                width: 963px;
            }
        </style>
	</head>
<body> 
    <header >  <img id="logo" src="../assets/css/img/imagen2.png" align="left"  >
 
        <div class="auto-style2">
            <div id="marca">
          <a class="resal" href="../login.blade.php" style="border-width: medium; border-style: double; font-weight: bold; background-color: #000000"> Cerrar Sesion </a> 
           <br>
          
            </div>
            <nav class="nav">
                <ul class="menu_main">
                    <li> <a href="#">Inicio  </a> </li>
                    <li> <a href="#">Inscripción Apoyos</a> 
                        <ul class="sub_menu">
                        <li><a href="ConvocatoriasDisponibles.aspx">-Convocatorias   disponibles</a></li>
                        <li><a href="CrearInscripcionApoyoS.aspx">-Inscripciones apoyos de sostenimiento</a></li>
                        <li><a href="CrearInscripcionApoyoA.aspx">-Inscripciones apoyos de alimentacion</a></li>
                        </ul>
                    </li>
                    <li> <a href="#"> Psicologos </a> 
                        <ul class="sub_menu">
                        <li><a href="PedirCitaP.aspx">-Pedir Cita</a></li>
                        <li><a href="CitasAsignadas.aspx">-Ver citas ya asiagnadas </a></li>
                        </ul>
                    </li>
                    <li> <a href="#"> Enfermeria </a> 
                        <ul class="sub_menu">
                            <li><a href="PedirCitaE.aspx">-Pedir Cita</a></li>
                            <li><a href="CitasAsignadasE.aspx">-Ver citas ya asiagnadas </a></li>
                       </ul>
                    </li>
                    <li> <a href="#"> Cultura Y Deporte  </a> 
                        <ul class="sub_menu">
                        <li><a href="ConvocatoriaCultura.aspx">-Convocatorias disponibles</a></li> 
                        <li><a href="InscripcionEventos.aspx">-Inscripcion a eventos deportivos</a></li>
                        <li><a href="VerInscripcion.aspx">-Ver inscripciones </a></li>
                        </ul>
                    </li>
                    <li> <a href="#"> Eventos</a> 
                        <ul class="sub_menu">
                        <li><a href="EventosObligatorios.aspx">-Eventos obligatorios</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
        </header>
       
</body>
</html>
