<!DOCTYPE html>
<html lang="es">
<head>
    <title>Bienestar Al Aprendiz</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link href="../assets/css/StyleSheet1.css" rel="stylesheet" />
    <style type="text/css">
       .auto-style1 {
            left: -2px;
            bottom: 1px;
            height: 12px;
        }
        .auto-style2 {
            width: 90%;
            margin: auto;
            overflow: hidden;
            height: 90px;
        }
        .auto-style3 {
            width: 833px;
        }
        .eventosO{
            width: 750px;
        }
      
    </style>
</head>
<body>
    <header >   <img id="logo" src="../assets/css/img/imagen2.png" align="left"  >
 
        <div class="auto-style2">
            <div id="marca">
           <h1 class="resaltado"> BIENESTAR AL APRENDIZ SENA</h1> <h5 class="resal">Lider: Nombre</h5>
            </div>
            <nav class="nav">
                <ul class="menu_main">
                    <li> <a onclick="location.href='../../../PaginaMaestraLider.html'" href="#"> Inicio </a> </li>
                    <li> <a href="#"> Inscripción Apoyos</a> 
                        <ul class="sub_menu">
                            <li><a onclick="location.href='../Apoyos/ConsultarApoyosSosteLider.html'" href="#">-Consultar Inscripciones apoyos de sostenimiento</a></li>
                            <br>
                            <br>
                            <li><a onclick="location.href='../Apoyos/ConsultarApoyosAlimenLider.html'" href="#">-Consultar Inscripciones apoyos de alimentacion</a></li>
                            <br>
                            <br>
                            <li><a onclick="location.href='../Apoyos/Apoyos solicitud cancelacion inscripciones.html'"href="#">-Ver Solicitud de cancelación a inscripciones</a></li> 
                            <br>
                            <br>
                            <li><a onclick="location.href='../Apoyos/Crear inscripcion aprendiz apoyos de sostenimiento.html'"href="#">Crear inscripcion aprendiz apoyos de sostenimiento</a></li>
                            <br>
                            <br> 
                            <li><a onclick="location.href='../Apoyos/Crear inscripcion aprendiz apoyos de alimentacion.html'"href="#">Crear inscripcion aprendiz apoyos de alimentacion</a></li>
                            <br>
                            <br>
                            <li><a onclick="location.href='../Apoyos/Crear convocatoria apoyos de alimentacion.html'"href="#">-Crear convocatorias de apoyos Alimentación</a></li>
                            <br>
                            <br>
                            <li><a  onclick="location.href='../Apoyos/Crear convocatoria apoyos de sotenimiento.html'" href="#">-Crear convocatorias de apoyos Sotenimiento</a></li>
                            <br>
                            <br>
                            <li><a  onclick="location.href='../Apoyos/GenerarRegistros.html'" href="#">-Generar registros </a></li>
                            <br>
                            <br> 
                            <li><a  onclick="location.href='../Apoyos/Ver registros.html'" href="#">-Ver registros </a></li>
                            <br>
                            <br> 
                        
                        </ul>
                    </li>
                    <li> <a href="#"> Psicologos </a> 
                        <ul class="sub_menu">
                        <li><a onclick="location.href='../Psicologia/ConsultarCitasPsicologiaLider.html'" href="#">-Consultar Citas </a></li>
                        <br>
                        <li><a onclick="location.href='../Psicologia/VerCitas.html'" href="#">-Ver citas Solicitadas</a></li> <br>
                         <br>
                         <li><a onclick="location.href='../Psicologia/VerCancelacioncitas.html'" href="#">-Ver Solicitud de cancelación de citas ya asignadas</a></li><br>
                         <br>
                         <li><a onclick="location.href='../Psicologia/CitasPsicologia.html'" href="#">-Crear, editar, consultar citas</a></li><br>
                         <br>
                         <li><a onclick="location.href='../Psicologia/GenerarRegistros.html'" href="#">-Generar registros</a></li><br>
                         <br>
                         <li><a onclick="location.href='../Psicologia/Ver registros.html'" href="#">-Ver registros</a></li><br>
                         <br>
                        </ul>
                    </li>
                    <li> <a href="#"> Enfermeria </a> 
                        <ul class="sub_menu">
                            <li><a onclick="location.href='../Enfermeria/ConsultarCitasEnfermeriaLider.html'" href="#">-Consultar Citas</a></li>   <br>
                            <br>
                            <li><a onclick="location.href='../Enfermeria/VerCitas.html'" href="#">-Ver citas Solicitadas</a></li> <br>
                            <br>
                            <li><a onclick="location.href='../Enfermeria/VerCancelacioncitas.html'" href="#">-Ver Solicitud de cancelación de citas ya asignadas</a></li><br>
                            <br>
                            <li><a onclick="location.href='../Enfermeria/CitasEnfermeria.html'" href="#">-Crear, editar, consultar citas</a></li><br>
                            <br>
                            <li><a onclick="location.href='../Enfermeria/GenerarRegistros.html'" href="#">-Generar registros</a></li><br>
                            <br>
                            <li><a onclick="location.href='../Enfermeria/Ver registros.html'" href="#">-Ver registros</a></li><br>
                            <br>
                       </ul>
                    </li>
                    <li> <a href="#"> Cultura Y Deporte  </a> 
                        <ul class="sub_menu">
                            <li><a onclick="location.href='../Cultura y deporte/VerInscripcionesCulturayDeporte.html'" href="#" >-Ver inscripciones a eventos culturales y deportivos</a></li>   
                        <br>
                        <br>
                        <li><a  onclick="location.href='../Cultura y deporte/CrearIncripcionesEventos.html'"href="#">-Crear, Consultar, Editar y Cancelar Inscripción a eventos culturales y deportivos</a></li>
                        <br>
                        <br>
                        <li><a  onclick="location.href='../Cultura y deporte/Solicitud cancelacion inscripciones.html'"href="#">-Ver solicitud de cancelacion de inscripción</a></li>
                        <br>
                        <br>
                        <li><a  onclick="location.href='../Cultura y deporte/Crear evento cultural y deportivo.html'"href="#">-Crear, Consultar, Editar y eliminar eventos deportivos</a></li>
                        <br>
                        <br>
                        </ul>
                    </li>
                    <li> <a href="#"> Eventos obligatorios  </a> 
                        <ul class="sub_menu">
                            <li><a onclick="location.href='EventosObligatorios.html'" href="#">-Eventos obligatorios</a></li>
                            <br>
                            <br>
                            <li><a onclick="location.href='Crear,editar,eliminar.. eventos obligatorios.html'" href="#">-Crear, Modificar y Eliminar Eventos obligatorios</a></li>
                            <br>
                            <br>
                    <br>
                    </ul>
                    </li>
                </ul>
            </nav>
        </div>

        </header>
    <center>
        <br><br><br><br><br><br>
        <h1>Eventos Obligatorios</h1 >
        <br><br><br><br>

    <table class="eventosO">
    <tr>
        <th>Codigo de evento</th>
        <th>Nombre de evento</th>
        <th>Fecha </th>
        <th>Hora</th>
        <th>Lugar</th>
    </tr>
  
    <tr>
        <td>879</td>
        <td>Tecnologías para la Educación</td>
        <td>03/05/2021</td>
        <td>13:00:00</td>
        <td>AUTOMA</td>
    </tr>
  </table></center>
            
        </body>
    </html>
    