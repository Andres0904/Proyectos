<!DOCTYPE html>
<html lang="es">
<head>
    <title>Bienestar Al Aprendiz</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link href="../../../css/StyleSheet1.css" rel="stylesheet" />
    <style type="text/css">
        .auto-style1 {
            left: -2px;
            bottom: 1px;
            height: 12px;
        }
        .auto-style2 {
            width: 90%;
            margin: auto;
            overflow: hidden;
            height: 105px;
        }
        .auto-style3 {
            width: 833px;
        }
    </style>
</head>
<body>

    <header >   <img id="logo" src="../../../img/imagen2.png" align="left"  >
 
        <div class="auto-style2">
            <div id="marca">
           <h1 class="resaltado"> BIENESTAR AL APRENDIZ SENA</h1>  <h5 class="resal">Aprendiz: Nombre</h5>
           <br>
          
            </div>
            <nav class="nav">
                <ul class="menu_main">
                    <li> <a  onclick="location.href='../../PaginaMaestra.html'" href="#"> Inicio </a> </li>
                    <li> <a href="#">Inscripción Apoyos</a> 
                        <ul class="sub_menu">
                            <li><a onclick="location.href='ConvocatoriasDispo.html'" href="#">-Convocatorias disponibles</a></li>
                        <br>
                        <br>
                        <li><a href="InsCancelacionApoyos.html">-Inscripciones y cancelacion apoyos de sostenimiento</a></li>
                        <br>
                        <br>
                        <li><a href="InscripcionCancelarAlimentacion.html">-Inscripciones y cancelacion apoyos de alimentacion</a></li>
                        <br>
                        <br>
                       
                        </ul>
                    </li>
                    <li> <a href="#"> Psicologos </a> 
                        <ul class="sub_menu">
                        <li><a href="SolicitarCitaPs.html">-Pedir Cita</a></li>
                        <br>
                        <br>
                        <li><a href="VercitasAsignadasPs.html">-Ver citas ya asiagnadas </a></li>
                        <br>
                        <br>
                        <li><a href="RetirarSolicitarPsicologo.html">-Retirar solicitud o solicitar cancelar cita ya asignada </a></li>
                        </ul>
                    </li>
                    <li> <a href="#"> Enfermeria </a> 
                        <ul class="sub_menu">
                            <li><a href="SolicitarCitaEnfe.html">-Pedir Cita</a></li>
                            <br>
                            <br>
                            <li><a href="VercitasAsignadasEnf.html">-Ver citas ya asiagnadas </a></li>
                            <br>
                            <br>
                            <li><a href="RetirarSolicitarEnfermeria.html">-Retirar solicitud o solicitar cancelar cita ya asignada </a></li>
                            <br>
                            <br>
                       </ul>
                    </li>
                    <li> <a href="#"> Cultura Y Deporte  </a> 
                        <ul class="sub_menu">
                        <li><a href="ConvoDispoCultyDeporte.html">-Convocatorias disponibles</a></li>   <br>
                        <br>
                        <li><a href="InscripcionEventosCultyDeprt.html">-Inscripcion a eventos deportivos y culturales</a></li>   <br>
                        <br>
                        <li><a href="VerInscrCulturaY deport.html">-Ver inscripciones </a></li>
                        </ul>
                    </li>
                    <li> <a href="#"> Eventos obligatorios  </a> 
                        <ul class="sub_menu">
                        <li><a href="#">-Eventos obligatorios</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    <br>
    <br>
    <center><h1 >Consultar Convocatorias de Cultura y Deporte</h1 >
        <br><br><br><br><br>
       
       
   
    </center> 
            <h2 class="Ins">Convocatorias </h2>  
    <center>     
    <table class="instructor">

        <tr>
            <th>Codigo de evento</th>
            <th>Nombre de evento</th>
          <th>Fecha de inicio</th>
          <th>Fecha de final</th>
          <th>Estado</th>
        
          
      
        </tr>
      
        <tr>
            <td>909</td>
            <td>Tecnologias del mañana</td>
          <td>02-02-2020</td>
          <td>03-03-2020</td>
          <td>Disponible</td>
          
      
        </tr>
      
</table></center>
</body>
</html>